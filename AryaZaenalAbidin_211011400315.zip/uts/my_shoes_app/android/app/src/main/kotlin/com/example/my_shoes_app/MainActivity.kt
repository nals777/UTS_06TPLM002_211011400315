package com.example.my_shoes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
